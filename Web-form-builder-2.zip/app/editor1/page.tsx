'use client'; 
import 'grapesjs/dist/css/grapes.min.css';
import grapesjs from 'grapesjs';
import { useEffect } from 'react';

export default function BasicEditor() {
    useEffect(() => {
        const editor = grapesjs.init({
            container: '#gjs',
            fromElement: true,
            panels: { defaults: [] },
            deviceManager: {
                devices: [
                    {
                        name: 'Desktop',
                        width: '',
                    },
                    {
                        name: 'Tablet',
                        width: '768px',
                        widthMedia: '992px',
                    },
                    {
                        name: 'Mobile',
                        width: '320px',
                        widthMedia: '480px',
                    },
                ],
            },
            blockManager: {
                appendTo: '#blocks',
            }
        });
        editor.Panels.addPanel({
            id: 'panel-top',
            el: '.panel__top',
        });


        editor.Panels.addPanel({
            id: 'panel-left',
            el: '.panel__basic-actions',
           buttons: [
            {
                id: 'device-desktop',
                label: `<i class="fa fa-desktop"></i>`, // Font Awesome icon
                command: 'set-device-desktop',
                active: true,
                togglable: false,
            },
            {
                id: 'device-tablet',
                label: `<i class="fa fa-tablet"></i>`, // Tablet icon
                command: 'set-device-tablet',
                togglable: false,
            },
            {
                id: 'device-mobile',
                label: `<i class="fa fa-mobile"></i>`, // Mobile icon
                command: 'set-device-mobile',
                togglable: false,
            },
        ],
        });

        editor.Panels.addPanel({
            id: 'panel-right',
            el: '.panel__view-buttons',
            buttons: [
                {
                    id: 'view-components',
                    label: `<i class="fa fa-square" title="Components"></i>`,
                    command: 'sw-visibility',
                    togglable: true,
                },
                {
                    id: 'view-style',
                    label: `<i class="fa fa-expand" title="Toggle Fullscreen"></i>`,
                    command: 'custom:toggle-fullscreen',
                    togglable: true,
                },
                {
                    id: 'view-code',
                    label: `<i class="fa fa-code" title="Code View"></i>`,
                    command: 'custom:toggle-code',
                    togglable: false,
                },
                {
                    id: 'undo',
                    label: `<i class="fa fa-undo" title="Undo"></i>`,
                    command: 'core:undo',
                    togglable: false,
                },
                {
                    id: 'redo',
                    label: `<i class="fa fa-repeat" title="Redo"></i>`,
                    command: 'core:redo',
                    togglable: false,
                },
                {
                    id: 'download',
                    label: `<i class="fa fa-download" title="Download HTML & CSS"></i>`,
                    command: 'custom:download',
                    togglable: false,
                },
                {
                    id: 'delete',
                    label: `<i class="fa fa-trash" title="Clear Canvas"></i>`,
                    command: 'custom:clear-canvas',
                    togglable: false,
                },
                {
                    id: 'open-style-manager',
                    label: `<i class="fa fa-paint-brush" title="Style Manager"></i>`,
                    command: 'core:open-sm',
                    togglable: true,
                },
                {
                    id: 'open-layer-manager',
                    label: `<i class="fa fa-clone" title="Layer Manager"></i>`,
                    command: 'core:open-layers',
                    togglable: true,
                },
                {
                    id: 'open-blocks',
                    label: `<i class="fa fa-plus" title="Open Blocks"></i>`,
                    command: 'custom:toggle-blocks-panel',
                    togglable: true,
                },
                {
                    id: 'about-us',
                    label: `<i class="fa fa-info-circle" title="About Us (Assets Modal)"></i>`,
                    command: 'open-assets',
                    togglable: false,
                },
            ],                                        
        });
        
        // Commands
        editor.Commands.add('set-device-desktop', {
            run: (editor) => editor.setDevice('Desktop'),
        });
        editor.Commands.add('set-device-mobile', {
            run: (editor) => editor.setDevice('Mobile'),
        });
        editor.Commands.add('set-device-tablet', {
            run: (editor) => editor.setDevice('Tablet'),
        });
        editor.Commands.add('custom:toggle-code', {
            run(editor) {
                const modal = editor.Modal;
                if (!modal.isOpen()) {
                editor.runCommand('core:open-code');
                } else {
                modal.close();
                }
            }
        });

        editor.Commands.add('custom:toggle-fullscreen', {
            run(editor) {
                const elem = document.documentElement;

                if (!document.fullscreenElement) {
                elem.requestFullscreen().catch(err => {
                    console.warn(`Error attempting to enable full-screen mode: ${err.message}`);
                });
                } else {
                    document.exitFullscreen();
                }
            }
        });

        editor.Commands.add('custom:download', {
            run(editor) {
                const html = editor.getHtml();
                const css = editor.getCss();
                const content = `
                <!DOCTYPE html>
                <html>
                    <head>
                    <style>${css}</style>
                    </head>
                    <body>${html}</body>
                </html>
                `;
                const blob = new Blob([content], { type: 'text/html' });
                const a = document.createElement('a');
                a.href = URL.createObjectURL(blob);
                a.download = 'page.html';
                a.click();
            }
        });

        editor.Commands.add('custom:clear-canvas', {
            run(editor) {
                if (confirm('Are you sure you want to clear the canvas?')) {
                editor.DomComponents.clear();
                editor.CssComposer.clear();
                }
            }
        });

        editor.Commands.add('custom:toggle-blocks-panel', {
            run() {
                const panel = document.getElementById('blocks');
                if (!panel) return; // Exit if panel is not found

                if (panel.style.display === 'none' || !panel.style.display) {
                panel.style.display = 'block';
                editor.runCommand('open-blocks');
                } else {
                panel.style.display = 'none';
                }
            }
        });

        // 1. Manually create the "Forms" category
        editor.BlockManager.getCategories().add({
            id: 'Forms',
            label: 'Forms',
            open: true, 
        });
        editor.BlockManager.add('1-column', {
            label: '1 Column',
            category: 'Layout',
            content: `<div class="row"><div class="column" style="padding:10px; min-height:50px;">1 Column</div></div>`,
        });

        editor.BlockManager.add('2-column', {
        label: '2 Columns',
        category: 'Layout',
        content: `
            <div class="row" style="display: flex;">
            <div class="column" style="flex: 1; padding:10px; min-height:50px;">Column 1</div>
            <div class="column" style="flex: 1; padding:10px; min-height:50px;">Column 2</div>
            </div>
        `,
        });

        editor.BlockManager.add('3-column', {
        label: '3 Columns',
        category: 'Layout',
        content: `
            <div class="row" style="display: flex;">
            <div class="column" style="flex: 1; padding:10px;">Col 1</div>
            <div class="column" style="flex: 1; padding:10px;">Col 2</div>
            <div class="column" style="flex: 1; padding:10px;">Col 3</div>
            </div>
        `,
        });

        editor.on('load', () => {
             editor.BlockManager.getCategories().each((cat: any) => {
                 cat.set('open', true);
             });
         });
        return () => editor.destroy(); // cleanup on unmount
    }, []);   
    return (
        <div>
            <div className="editor-row">
                <div className="panel__top">
                <div className="panel__left">
                    <div className="panel__basic-actions"></div>
                </div>
                <div className="panel__right">
                    <div className="panel__view-buttons"></div>
                </div>
                </div>

                <div className="editor-body" style={{ display: 'flex' }}>
                {/* Left canvas */}
                <div className="editor-canvas" style={{ flex: 1 }}>
                    <div id="gjs">Your editor canvas here...</div>
                </div>
                
                {/* Right sidebar (initially hidden) */}
                    <div id="blocks" className='blocks-panel'></div> 
               </div>
            </div>
            </div>
    );
}